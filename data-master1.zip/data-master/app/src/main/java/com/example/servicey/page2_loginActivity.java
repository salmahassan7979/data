package com.example.servicey;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class page2_loginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2_login);
    }
}
